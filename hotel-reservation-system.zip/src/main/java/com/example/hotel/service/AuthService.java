package com.example.hotel.service;

import com.example.hotel.dto.LoginRequest;
import com.example.hotel.dto.UserSession;
import com.example.hotel.model.UserAccount;
import com.example.hotel.model.UserRole;
import com.example.hotel.repository.HotelDatabase;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class AuthService {
    private final HotelDatabase database;
    // 简单内存会话表：登录成功后生成 token，后续请求通过 X-Auth-Token 校验。
    private final Map<String, UserSession> sessions = new ConcurrentHashMap<>();

    public AuthService(HotelDatabase database) {
        this.database = database;
    }

    public UserSession login(LoginRequest request) {
        // 登录时先校验必填项，再用 SHA-256 哈希后的密码和数据库中密码哈希比对。
        if (request == null || !StringUtils.hasText(request.getUsername()) || !StringUtils.hasText(request.getPassword())) {
            throw new IllegalArgumentException("请输入账号和密码");
        }
        UserAccount user = database.findUserByUsername(request.getUsername().trim());
        if (user == null || !Boolean.TRUE.equals(user.getEnabled()) || !hashPassword(request.getPassword()).equals(user.getPasswordHash())) {
            throw new IllegalArgumentException("账号或密码错误");
        }
        String token = UUID.randomUUID().toString().replace("-", "");
        UserSession session = toSession(token, user);
        sessions.put(token, session);
        return session;
    }

    public UserSession requireLogin(String token) {
        // 所有业务接口都至少要求已登录，未登录时抛出统一提示。
        UserSession session = sessions.get(token);
        if (session == null) throw new IllegalArgumentException("请先登录");
        return session;
    }

    public UserSession requireAdmin(String token) {
        // 管理员权限：数据库查看、清空记录、删除基础数据等高风险操作使用。
        UserSession session = requireLogin(token);
        if (!UserRole.ADMIN.name().equals(session.getRole())) throw new IllegalArgumentException("当前账号没有管理员权限");
        return session;
    }

    public UserSession requireManager(String token) {
        // 经理权限：管理员和经理都能进行房型、客房等基础维护。
        UserSession session = requireLogin(token);
        if (!UserRole.ADMIN.name().equals(session.getRole()) && !UserRole.MANAGER.name().equals(session.getRole())) {
            throw new IllegalArgumentException("当前账号没有经理权限");
        }
        return session;
    }

    public UserSession requireFrontDesk(String token) {
        // 前台业务权限：管理员、经理、前台可处理预订；保洁只维护房态。
        UserSession session = requireLogin(token);
        if (UserRole.HOUSEKEEPING.name().equals(session.getRole())) {
            throw new IllegalArgumentException("当前账号没有前台业务权限");
        }
        return session;
    }

    public void logout(String token) {
        if (token != null) sessions.remove(token);
    }

    public static String hashPassword(String password) {
        try {
            // 课程项目中使用 SHA-256 保存密码哈希，避免数据库直接存明文密码。
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder builder = new StringBuilder();
            for (byte b : bytes) builder.append(String.format("%02x", b));
            return builder.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("密码加密失败", e);
        }
    }

    private UserSession toSession(String token, UserAccount user) {
        return new UserSession(token, user.getUsername(), user.getDisplayName(), user.getRole().name(), user.getRole().getLabel());
    }
}
