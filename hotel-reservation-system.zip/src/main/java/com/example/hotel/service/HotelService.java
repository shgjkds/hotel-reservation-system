package com.example.hotel.service;

import com.example.hotel.dto.CheckInRequest;
import com.example.hotel.dto.CheckoutRequest;
import com.example.hotel.dto.DashboardSummary;
import com.example.hotel.dto.ReservationView;
import com.example.hotel.dto.RoomView;
import com.example.hotel.model.Reservation;
import com.example.hotel.model.ReservationStatus;
import com.example.hotel.model.Room;
import com.example.hotel.model.RoomStatus;
import com.example.hotel.model.RoomType;
import com.example.hotel.repository.HotelDatabase;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class HotelService {
    private final HotelDatabase database;
    // 业务层使用内存 Map 做一次数据组织，实际持久化仍以 MySQL 为准。
    private final Map<Long, RoomType> roomTypes = new LinkedHashMap<>();
    private final Map<Long, Room> rooms = new LinkedHashMap<>();
    private final Map<Long, Reservation> reservations = new LinkedHashMap<>();

    public HotelService(HotelDatabase database) {
        this.database = database;
        // 项目启动时初始化数据库表和默认数据。
        this.database.initialize();
    }

    public synchronized List<RoomType> listRoomTypes() {
        loadData();
        return new ArrayList<>(roomTypes.values());
    }

    public synchronized RoomType saveRoomType(RoomType roomType) {
        // 新增或编辑房型：统一做必填校验和价格校验，再交给数据库层保存。
        loadData();
        requireText(roomType.getName(), "房型名称不能为空");
        if (roomType.getCapacity() == null || roomType.getCapacity() <= 0) throw new IllegalArgumentException("可住人数必须大于 0");
        if (roomType.getPrice() == null || roomType.getPrice().compareTo(BigDecimal.ZERO) < 0) throw new IllegalArgumentException("房价不能为负数");
        if (roomType.getId() == null) {
            database.insertRoomType(roomType);
        } else if (roomTypes.containsKey(roomType.getId())) {
            database.updateRoomType(roomType);
        } else {
            throw new IllegalArgumentException("房型不存在");
        }
        loadData();
        return roomType;
    }

    public synchronized void deleteRoomType(Long id) {
        loadData();
        // 已经被客房使用的房型不能删除，避免 rooms.type_id 外键失效。
        if (rooms.values().stream().anyMatch(room -> room.getTypeId().equals(id))) throw new IllegalArgumentException("已有房间使用该房型，不能删除");
        database.deleteRoomType(id);
    }

    public synchronized List<RoomView> listRooms() {
        loadData();
        return rooms.values().stream().sorted(Comparator.comparing(Room::getRoomNumber)).map(this::toRoomView).collect(Collectors.toList());
    }

    public synchronized Room saveRoom(Room room) {
        // 新增或编辑客房：房号必须唯一，且必须绑定已存在的房型。
        loadData();
        requireText(room.getRoomNumber(), "房号不能为空");
        requireRoomType(room.getTypeId());
        if (room.getStatus() == null) room.setStatus(RoomStatus.AVAILABLE);
        boolean duplicate = rooms.values().stream().anyMatch(item -> item.getRoomNumber().equals(room.getRoomNumber()) && !item.getId().equals(room.getId()));
        if (duplicate) throw new IllegalArgumentException("房号已存在");
        if (room.getId() == null) database.insertRoom(room);
        else if (rooms.containsKey(room.getId())) database.updateRoom(room);
        else throw new IllegalArgumentException("客房不存在");
        return room;
    }

    public synchronized void deleteRoom(Long id) {
        loadData();
        Room room = requireRoom(id);
        // 有预订历史的房间不允许删除，避免历史订单找不到对应房号。
        boolean hasReservation = reservations.values().stream().anyMatch(item -> item.getRoomId().equals(room.getId()));
        if (hasReservation) throw new IllegalArgumentException("该客房已有预订记录，不能删除");
        database.deleteRoom(id);
        loadData();
    }

    public synchronized Room updateRoomStatus(Long id, RoomStatus status) {
        // 房态下拉修改：根据状态自动补充或清理默认备注。
        loadData();
        Room room = requireRoom(id);
        RoomStatus old = room.getStatus();
        room.setStatus(status);
        if (status == RoomStatus.MAINTENANCE && !StringUtils.hasText(room.getRemark())) room.setRemark("待维修");
        if (status == RoomStatus.CLEANING && !StringUtils.hasText(room.getRemark())) room.setRemark("等待清扫");
        if (old == RoomStatus.MAINTENANCE && status != RoomStatus.MAINTENANCE && ("待维修".equals(room.getRemark()) || "空调检修".equals(room.getRemark()))) room.setRemark("");
        if (old == RoomStatus.CLEANING && status != RoomStatus.CLEANING && "等待清扫".equals(room.getRemark())) room.setRemark("");
        database.updateRoom(room);
        return room;
    }

    public synchronized List<ReservationView> listReservations(String keyword, ReservationStatus status) {
        // 支持按关键字和预订状态过滤，返回给页面时转成 ReservationView。
        loadData();
        return reservations.values().stream()
                .filter(item -> status == null || item.getStatus() == status)
                .filter(item -> matchesKeyword(item, keyword))
                .sorted(Comparator.comparing(Reservation::getCreatedAt).reversed())
                .map(this::toReservationView).collect(Collectors.toList());
    }

    public synchronized ReservationView createReservation(Reservation reservation) {
        // 保存预订：校验日期和房间可用性，计算金额，并将房间状态改为已预订。
        loadData();
        requireText(reservation.getGuestName(), "客人姓名不能为空");
        requireText(reservation.getPhone(), "联系电话不能为空");
        RoomType type = requireRoomType(reservation.getRoomTypeId());
        long nights = ChronoUnit.DAYS.between(reservation.getCheckInDate(), reservation.getCheckOutDate());
        if (nights <= 0) throw new IllegalArgumentException("离店日期必须晚于入住日期");
        Room room = reservation.getRoomId() == null ? findAvailableRoom(type.getId()) : requireRoom(reservation.getRoomId());
        if (!room.getTypeId().equals(type.getId())) throw new IllegalArgumentException("所选房间不属于该房型");
        if (room.getStatus() != RoomStatus.AVAILABLE) throw new IllegalArgumentException("所选房间当前不可预订");
        reservation.setRoomId(room.getId());
        reservation.setGuests(reservation.getGuests() == null ? 1 : reservation.getGuests());
        reservation.setDeposit(defaultMoney(reservation.getDeposit()));
        reservation.setTotalAmount(type.getPrice().multiply(BigDecimal.valueOf(nights)));
        reservation.setStatus(ReservationStatus.BOOKED);
        reservation.setCreatedAt(LocalDateTime.now());
        database.insertReservation(reservation);
        room.setStatus(RoomStatus.RESERVED);
        database.updateRoom(room);
        loadData();
        return toReservationView(reservation);
    }

    public synchronized ReservationView checkIn(Long id, CheckInRequest request) {
        // 入住登记：只有 BOOKED 记录可入住，入住后房态变为 OCCUPIED。
        loadData();
        Reservation reservation = requireReservation(id);
        if (reservation.getStatus() != ReservationStatus.BOOKED) throw new IllegalArgumentException("只有已预订记录可以办理入住");
        if (StringUtils.hasText(request.getIdCard())) reservation.setIdCard(request.getIdCard());
        if (request.getExtraDeposit() != null) reservation.setDeposit(reservation.getDeposit().add(request.getExtraDeposit()));
        reservation.setStatus(ReservationStatus.CHECKED_IN);
        reservation.setCheckedInAt(LocalDateTime.now());
        Room room = requireRoom(reservation.getRoomId());
        room.setStatus(RoomStatus.OCCUPIED);
        database.updateReservation(reservation);
        database.updateRoom(room);
        return toReservationView(reservation);
    }

    public synchronized ReservationView checkout(Long id, CheckoutRequest request) {
        // 退房结算：计算额外消费和优惠，结算后房态进入清扫中。
        loadData();
        Reservation reservation = requireReservation(id);
        if (reservation.getStatus() != ReservationStatus.CHECKED_IN) throw new IllegalArgumentException("只有入住中记录可以办理退房结算");
        BigDecimal total = reservation.getTotalAmount().add(defaultMoney(request.getExtraCharge())).subtract(defaultMoney(request.getDiscount()));
        reservation.setTotalAmount(total.compareTo(BigDecimal.ZERO) < 0 ? BigDecimal.ZERO : total);
        reservation.setStatus(ReservationStatus.CHECKED_OUT);
        reservation.setCheckedOutAt(LocalDateTime.now());
        reservation.setNote(appendNote(reservation.getNote(), "支付方式：" + (StringUtils.hasText(request.getPaymentMethod()) ? request.getPaymentMethod() : "现金")));
        Room room = requireRoom(reservation.getRoomId());
        room.setStatus(RoomStatus.CLEANING);
        if (!StringUtils.hasText(room.getRemark())) room.setRemark("等待清扫");
        database.updateReservation(reservation);
        database.updateRoom(room);
        return toReservationView(reservation);
    }

    public synchronized ReservationView cancelReservation(Long id) {
        // 取消预订：只允许取消未入住的预订，并释放房间为空闲。
        loadData();
        Reservation reservation = requireReservation(id);
        if (reservation.getStatus() != ReservationStatus.BOOKED) throw new IllegalArgumentException("只有已预订记录可以取消");
        reservation.setStatus(ReservationStatus.CANCELLED);
        Room room = requireRoom(reservation.getRoomId());
        room.setStatus(RoomStatus.AVAILABLE);
        database.updateReservation(reservation);
        database.updateRoom(room);
        return toReservationView(reservation);
    }

    public synchronized void clearReservations() {
        // 管理员清空预订记录时，同时刷新内存缓存，保证页面立即同步。
        database.clearReservations();
        loadData();
    }

    public synchronized DashboardSummary dashboard() {
        // 仪表盘统计：客房数、空闲数、待入住数、入住中数和预计营收。
        loadData();
        DashboardSummary summary = new DashboardSummary();
        summary.setTotalRooms(rooms.size());
        summary.setAvailableRooms((int) rooms.values().stream().filter(room -> room.getStatus() == RoomStatus.AVAILABLE).count());
        summary.setBookedCount((int) reservations.values().stream().filter(item -> item.getStatus() == ReservationStatus.BOOKED).count());
        summary.setCheckedInCount((int) reservations.values().stream().filter(item -> item.getStatus() == ReservationStatus.CHECKED_IN).count());
        summary.setExpectedRevenue(reservations.values().stream().filter(item -> item.getStatus() != ReservationStatus.CANCELLED).map(Reservation::getTotalAmount).reduce(BigDecimal.ZERO, BigDecimal::add));
        Map<String, Long> statusCounts = new LinkedHashMap<>();
        for (RoomStatus status : RoomStatus.values()) statusCounts.put(status.name(), rooms.values().stream().filter(room -> room.getStatus() == status).count());
        summary.setStatusCounts(statusCounts);
        return summary;
    }

    private void loadData() {
        // 每次业务操作前从数据库重新加载，避免页面操作后看到旧数据。
        roomTypes.clear(); rooms.clear(); reservations.clear();
        for (RoomType type : database.findRoomTypes()) roomTypes.put(type.getId(), type);
        for (Room room : database.findRooms()) rooms.put(room.getId(), room);
        for (Reservation reservation : database.findReservations()) reservations.put(reservation.getId(), reservation);
    }

    private RoomView toRoomView(Room room) {
        // RoomView 合并房型价格、状态中文名和当前客人，方便前端直接展示。
        RoomType type = roomTypes.get(room.getTypeId());
        RoomView view = new RoomView();
        view.setId(room.getId()); view.setRoomNumber(room.getRoomNumber()); view.setFloor(room.getFloor()); view.setTypeId(room.getTypeId());
        view.setTypeName(type == null ? "未知房型" : type.getName()); view.setPrice(type == null ? BigDecimal.ZERO : type.getPrice());
        view.setStatus(room.getStatus()); view.setStatusLabel(room.getStatus().getLabel()); view.setRemark(room.getRemark()); view.setGuestName(findActiveGuest(room.getId()));
        return view;
    }

    private ReservationView toReservationView(Reservation r) {
        // ReservationView 合并房型名、房号、状态中文名，减少前端二次查询。
        RoomType type = roomTypes.get(r.getRoomTypeId()); Room room = rooms.get(r.getRoomId());
        ReservationView v = new ReservationView();
        v.setId(r.getId()); v.setGuestName(r.getGuestName()); v.setPhone(r.getPhone()); v.setIdCard(r.getIdCard());
        v.setRoomTypeId(r.getRoomTypeId()); v.setRoomTypeName(type == null ? "未知房型" : type.getName());
        v.setRoomId(r.getRoomId()); v.setRoomNumber(room == null ? "" : room.getRoomNumber());
        v.setCheckInDate(r.getCheckInDate()); v.setCheckOutDate(r.getCheckOutDate()); v.setGuests(r.getGuests());
        v.setDeposit(r.getDeposit()); v.setTotalAmount(r.getTotalAmount()); v.setStatus(r.getStatus()); v.setStatusLabel(r.getStatus().getLabel());
        v.setNote(r.getNote()); v.setCreatedAt(r.getCreatedAt()); v.setCheckedInAt(r.getCheckedInAt()); v.setCheckedOutAt(r.getCheckedOutAt());
        return v;
    }

    private Room findAvailableRoom(Long typeId) {
        // 自动分配房间时，选择当前房型下房号最靠前的空闲房。
        return rooms.values().stream().filter(room -> room.getTypeId().equals(typeId) && room.getStatus() == RoomStatus.AVAILABLE).sorted(Comparator.comparing(Room::getRoomNumber)).findFirst().orElseThrow(() -> new IllegalArgumentException("该房型暂无可预订房间"));
    }
    private String findActiveGuest(Long roomId) {
        return reservations.values().stream().filter(item -> item.getRoomId().equals(roomId)).filter(item -> item.getStatus() == ReservationStatus.BOOKED || item.getStatus() == ReservationStatus.CHECKED_IN).map(Reservation::getGuestName).findFirst().orElse("");
    }
    private boolean matchesKeyword(Reservation r, String keyword) {
        if (!StringUtils.hasText(keyword)) return true;
        String k = keyword.trim().toLowerCase();
        return contains(r.getGuestName(), k) || contains(r.getPhone(), k) || contains(r.getIdCard(), k);
    }
    private boolean contains(String text, String keyword) { return text != null && text.toLowerCase().contains(keyword); }
    private RoomType requireRoomType(Long id) { RoomType type = roomTypes.get(id); if (type == null) throw new IllegalArgumentException("房型不存在"); return type; }
    private Room requireRoom(Long id) { Room room = rooms.get(id); if (room == null) throw new IllegalArgumentException("客房不存在"); return room; }
    private Reservation requireReservation(Long id) { Reservation r = reservations.get(id); if (r == null) throw new IllegalArgumentException("预订记录不存在"); return r; }
    private void requireText(String value, String message) { if (!StringUtils.hasText(value)) throw new IllegalArgumentException(message); }
    private BigDecimal defaultMoney(BigDecimal value) { return value == null ? BigDecimal.ZERO : value; }
    private String appendNote(String oldNote, String newNote) { return StringUtils.hasText(oldNote) ? oldNote + "；" + newNote : newNote; }
}
