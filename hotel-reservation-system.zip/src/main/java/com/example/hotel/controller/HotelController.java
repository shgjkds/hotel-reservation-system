package com.example.hotel.controller;

import com.example.hotel.dto.CheckInRequest;
import com.example.hotel.dto.CheckoutRequest;
import com.example.hotel.dto.DashboardSummary;
import com.example.hotel.dto.DatabaseTableView;
import com.example.hotel.dto.LoginRequest;
import com.example.hotel.dto.ReservationView;
import com.example.hotel.dto.RoomView;
import com.example.hotel.dto.UserSession;
import com.example.hotel.model.Reservation;
import com.example.hotel.model.ReservationStatus;
import com.example.hotel.model.Room;
import com.example.hotel.model.RoomStatus;
import com.example.hotel.model.RoomType;
import com.example.hotel.repository.HotelDatabase;
import com.example.hotel.service.AuthService;
import com.example.hotel.service.HotelService;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
public class HotelController {
    // 控制层只负责接收 HTTP 请求、做权限校验、调用业务层，不直接写业务规则。
    private final HotelService hotelService;
    private final HotelDatabase hotelDatabase;
    private final AuthService authService;

    public HotelController(HotelService hotelService, HotelDatabase hotelDatabase, AuthService authService) {
        this.hotelService = hotelService;
        this.hotelDatabase = hotelDatabase;
        this.authService = authService;
    }

    @PostMapping("/auth/login")
    public UserSession login(@RequestBody LoginRequest request) { return authService.login(request); }

    @PostMapping("/auth/logout")
    public void logout(@RequestHeader(value = "X-Auth-Token", required = false) String token) { authService.logout(token); }

    @GetMapping("/dashboard")
    public DashboardSummary dashboard(@RequestHeader(value = "X-Auth-Token", required = false) String token) {
        // 登录后才能查看仪表盘统计数据。
        authService.requireLogin(token);
        return hotelService.dashboard();
    }

    @GetMapping("/room-types")
    public List<RoomType> roomTypes(@RequestHeader(value = "X-Auth-Token", required = false) String token) {
        authService.requireLogin(token);
        return hotelService.listRoomTypes();
    }

    @PostMapping("/room-types")
    public RoomType createRoomType(@RequestHeader(value = "X-Auth-Token", required = false) String token, @RequestBody RoomType roomType) {
        // 房型新增/编辑属于基础维护，管理员和经理可以操作。
        authService.requireManager(token);
        return hotelService.saveRoomType(roomType);
    }

    @PutMapping("/room-types/{id}")
    public RoomType updateRoomType(@RequestHeader(value = "X-Auth-Token", required = false) String token, @PathVariable Long id, @RequestBody RoomType roomType) {
        authService.requireManager(token);
        roomType.setId(id);
        return hotelService.saveRoomType(roomType);
    }

    @DeleteMapping("/room-types/{id}")
    public void deleteRoomType(@RequestHeader(value = "X-Auth-Token", required = false) String token, @PathVariable Long id) {
        // 删除基础数据风险较高，只开放给管理员。
        authService.requireAdmin(token);
        hotelService.deleteRoomType(id);
    }

    @GetMapping("/rooms")
    public List<RoomView> rooms(@RequestHeader(value = "X-Auth-Token", required = false) String token) {
        authService.requireLogin(token);
        return hotelService.listRooms();
    }

    @GetMapping("/room-map")
    public List<RoomView> roomMap(@RequestHeader(value = "X-Auth-Token", required = false) String token) {
        authService.requireLogin(token);
        return hotelService.listRooms();
    }

    @PostMapping("/rooms")
    public Room createRoom(@RequestHeader(value = "X-Auth-Token", required = false) String token, @RequestBody Room room) {
        // 客房新增/编辑属于基础维护，管理员和经理可以操作。
        authService.requireManager(token);
        return hotelService.saveRoom(room);
    }

    @DeleteMapping("/rooms/{id}")
    public void deleteRoom(@RequestHeader(value = "X-Auth-Token", required = false) String token, @PathVariable Long id) {
        authService.requireAdmin(token);
        hotelService.deleteRoom(id);
    }

    @PutMapping("/rooms/{id}/status")
    public Room updateRoomStatus(@RequestHeader(value = "X-Auth-Token", required = false) String token, @PathVariable Long id, @RequestParam RoomStatus status) {
        // 房态维护允许所有已登录角色操作，保洁主要使用这个接口。
        authService.requireLogin(token);
        return hotelService.updateRoomStatus(id, status);
    }

    @GetMapping("/reservations")
    public List<ReservationView> reservations(@RequestHeader(value = "X-Auth-Token", required = false) String token,
                                              @RequestParam(required = false) String keyword,
                                              @RequestParam(required = false) ReservationStatus status) {
        // 预订列表涉及客户信息，保洁角色不可查看。
        authService.requireFrontDesk(token);
        return hotelService.listReservations(keyword, status);
    }

    @PostMapping("/reservations")
    public ReservationView createReservation(@RequestHeader(value = "X-Auth-Token", required = false) String token, @RequestBody Reservation reservation) {
        authService.requireFrontDesk(token);
        return hotelService.createReservation(reservation);
    }

    @PostMapping("/reservations/{id}/check-in")
    public ReservationView checkIn(@RequestHeader(value = "X-Auth-Token", required = false) String token, @PathVariable Long id, @RequestBody(required = false) CheckInRequest request) {
        authService.requireFrontDesk(token);
        return hotelService.checkIn(id, request == null ? new CheckInRequest() : request);
    }

    @PostMapping("/reservations/{id}/checkout")
    public ReservationView checkout(@RequestHeader(value = "X-Auth-Token", required = false) String token, @PathVariable Long id, @RequestBody(required = false) CheckoutRequest request) {
        authService.requireFrontDesk(token);
        return hotelService.checkout(id, request == null ? new CheckoutRequest() : request);
    }

    @PostMapping("/reservations/{id}/cancel")
    public ReservationView cancelReservation(@RequestHeader(value = "X-Auth-Token", required = false) String token, @PathVariable Long id) {
        authService.requireFrontDesk(token);
        return hotelService.cancelReservation(id);
    }

    @DeleteMapping("/reservations")
    public void clearReservations(@RequestHeader(value = "X-Auth-Token", required = false) String token) {
        // 清空预订会删除业务数据，只允许管理员执行。
        authService.requireAdmin(token);
        hotelService.clearReservations();
    }

    @GetMapping("/database/tables")
    public List<String> databaseTables(@RequestHeader(value = "X-Auth-Token", required = false) String token) {
        // 数据库查看器属于管理员工具，普通角色不显示也不能访问接口。
        authService.requireAdmin(token);
        return hotelDatabase.tableNames();
    }

    @GetMapping("/database/tables/{tableName}")
    public DatabaseTableView databaseTable(@RequestHeader(value = "X-Auth-Token", required = false) String token, @PathVariable String tableName) {
        authService.requireAdmin(token);
        return hotelDatabase.tableView(tableName);
    }
}
