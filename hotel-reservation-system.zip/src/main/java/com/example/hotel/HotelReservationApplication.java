package com.example.hotel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelReservationApplication {
    // Spring Boot 项目启动入口，运行后会启动内置 Tomcat 并加载静态页面与 API。
    public static void main(String[] args) {
        SpringApplication.run(HotelReservationApplication.class, args);
    }
}
