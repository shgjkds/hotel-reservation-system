package com.example.hotel.dto;

import java.math.BigDecimal;

// 入住登记请求：可补录身份证号和追加押金。
public class CheckInRequest {
    private String idCard;
    private BigDecimal extraDeposit;
    public String getIdCard() { return idCard; }
    public void setIdCard(String idCard) { this.idCard = idCard; }
    public BigDecimal getExtraDeposit() { return extraDeposit; }
    public void setExtraDeposit(BigDecimal extraDeposit) { this.extraDeposit = extraDeposit; }
}
