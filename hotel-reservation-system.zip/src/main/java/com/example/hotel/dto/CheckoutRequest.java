package com.example.hotel.dto;

import java.math.BigDecimal;

// 退房结算请求：记录额外消费、优惠金额和支付方式。
public class CheckoutRequest {
    private BigDecimal extraCharge;
    private BigDecimal discount;
    private String paymentMethod;
    public BigDecimal getExtraCharge() { return extraCharge; }
    public void setExtraCharge(BigDecimal extraCharge) { this.extraCharge = extraCharge; }
    public BigDecimal getDiscount() { return discount; }
    public void setDiscount(BigDecimal discount) { this.discount = discount; }
    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }
}
