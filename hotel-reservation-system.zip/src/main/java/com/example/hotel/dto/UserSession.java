package com.example.hotel.dto;

// 登录成功后的会话信息：前端保存 token 并在后续请求中携带。
public class UserSession {
    private String token;
    private String username;
    private String displayName;
    private String role;
    private String roleLabel;

    public UserSession() {}

    public UserSession(String token, String username, String displayName, String role, String roleLabel) {
        this.token = token;
        this.username = username;
        this.displayName = displayName;
        this.role = role;
        this.roleLabel = roleLabel;
    }

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getDisplayName() { return displayName; }
    public void setDisplayName(String displayName) { this.displayName = displayName; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public String getRoleLabel() { return roleLabel; }
    public void setRoleLabel(String roleLabel) { this.roleLabel = roleLabel; }
}
