package com.example.hotel.dto;

import com.example.hotel.model.RoomStatus;
import java.math.BigDecimal;

// 客房展示 DTO：在 Room 基础上补充房型名称、价格、中文状态和当前客人。
public class RoomView {
    private Long id;
    private String roomNumber;
    private String floor;
    private Long typeId;
    private String typeName;
    private BigDecimal price;
    private RoomStatus status;
    private String statusLabel;
    private String guestName;
    private String remark;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getRoomNumber() { return roomNumber; }
    public void setRoomNumber(String roomNumber) { this.roomNumber = roomNumber; }
    public String getFloor() { return floor; }
    public void setFloor(String floor) { this.floor = floor; }
    public Long getTypeId() { return typeId; }
    public void setTypeId(Long typeId) { this.typeId = typeId; }
    public String getTypeName() { return typeName; }
    public void setTypeName(String typeName) { this.typeName = typeName; }
    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }
    public RoomStatus getStatus() { return status; }
    public void setStatus(RoomStatus status) { this.status = status; }
    public String getStatusLabel() { return statusLabel; }
    public void setStatusLabel(String statusLabel) { this.statusLabel = statusLabel; }
    public String getGuestName() { return guestName; }
    public void setGuestName(String guestName) { this.guestName = guestName; }
    public String getRemark() { return remark; }
    public void setRemark(String remark) { this.remark = remark; }
}
