package com.example.hotel.dto;

import java.util.List;
import java.util.Map;

// 数据库查看器 DTO：将任意允许查看的数据表转换成列名和行数据。
public class DatabaseTableView {
    private String tableName;
    private List<String> columns;
    private List<Map<String, Object>> rows;
    public DatabaseTableView() {}
    public DatabaseTableView(String tableName, List<String> columns, List<Map<String, Object>> rows) {
        this.tableName = tableName;
        this.columns = columns;
        this.rows = rows;
    }
    public String getTableName() { return tableName; }
    public void setTableName(String tableName) { this.tableName = tableName; }
    public List<String> getColumns() { return columns; }
    public void setColumns(List<String> columns) { this.columns = columns; }
    public List<Map<String, Object>> getRows() { return rows; }
    public void setRows(List<Map<String, Object>> rows) { this.rows = rows; }
}
