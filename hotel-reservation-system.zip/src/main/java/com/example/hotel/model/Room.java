package com.example.hotel.model;

// 客房实体：一间具体房间，关联房型并记录当前房态。
public class Room {
    private Long id;
    private String roomNumber;
    private String floor;
    private Long typeId;
    private RoomStatus status;
    private String remark;

    public Room() {}

    public Room(Long id, String roomNumber, String floor, Long typeId, RoomStatus status, String remark) {
        this.id = id;
        this.roomNumber = roomNumber;
        this.floor = floor;
        this.typeId = typeId;
        this.status = status;
        this.remark = remark;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getRoomNumber() { return roomNumber; }
    public void setRoomNumber(String roomNumber) { this.roomNumber = roomNumber; }
    public String getFloor() { return floor; }
    public void setFloor(String floor) { this.floor = floor; }
    public Long getTypeId() { return typeId; }
    public void setTypeId(Long typeId) { this.typeId = typeId; }
    public RoomStatus getStatus() { return status; }
    public void setStatus(RoomStatus status) { this.status = status; }
    public String getRemark() { return remark; }
    public void setRemark(String remark) { this.remark = remark; }
}
