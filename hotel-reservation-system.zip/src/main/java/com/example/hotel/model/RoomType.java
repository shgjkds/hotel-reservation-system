package com.example.hotel.model;

import java.math.BigDecimal;

// 房型实体：保存房型名称、床型、可住人数、价格和描述。
public class RoomType {
    private Long id;
    private String name;
    private String bedType;
    private Integer capacity;
    private BigDecimal price;
    private String description;

    public RoomType() {}

    public RoomType(Long id, String name, String bedType, Integer capacity, BigDecimal price, String description) {
        this.id = id;
        this.name = name;
        this.bedType = bedType;
        this.capacity = capacity;
        this.price = price;
        this.description = description;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getBedType() { return bedType; }
    public void setBedType(String bedType) { this.bedType = bedType; }
    public Integer getCapacity() { return capacity; }
    public void setCapacity(Integer capacity) { this.capacity = capacity; }
    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
