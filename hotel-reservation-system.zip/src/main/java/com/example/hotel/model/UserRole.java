package com.example.hotel.model;

// 用户角色枚举：不同角色对应不同页面菜单和后端接口权限。
public enum UserRole {
    ADMIN("管理员"),
    MANAGER("经理"),
    STAFF("前台员工"),
    HOUSEKEEPING("保洁");

    private final String label;

    UserRole(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
