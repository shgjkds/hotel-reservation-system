package com.example.hotel.model;

// 客房状态枚举：用于房态图展示和房间状态流转。
public enum RoomStatus {
    AVAILABLE("空闲"),
    RESERVED("已预订"),
    OCCUPIED("入住中"),
    CLEANING("清扫中"),
    MAINTENANCE("维修中");

    private final String label;

    RoomStatus(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
