package com.example.hotel.model;

// 预订状态枚举：表示订单从预订到入住、退房或取消的流程状态。
public enum ReservationStatus {
    BOOKED("已预订"),
    CHECKED_IN("已入住"),
    CHECKED_OUT("已退房"),
    CANCELLED("已取消");

    private final String label;

    ReservationStatus(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
