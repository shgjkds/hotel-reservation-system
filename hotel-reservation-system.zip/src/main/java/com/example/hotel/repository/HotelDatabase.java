package com.example.hotel.repository;

import com.example.hotel.dto.DatabaseTableView;
import com.example.hotel.model.Reservation;
import com.example.hotel.model.ReservationStatus;
import com.example.hotel.model.Room;
import com.example.hotel.model.RoomStatus;
import com.example.hotel.model.RoomType;
import com.example.hotel.model.UserAccount;
import com.example.hotel.model.UserRole;
import com.example.hotel.service.AuthService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Repository
public class HotelDatabase {
    // 数据库查看器允许展示的表名白名单，避免前端任意拼接 SQL 表名。
    private static final List<String> TABLE_NAMES = Arrays.asList("room_types", "rooms", "reservations", "users");

    @Value("${hotel.database.url}")
    private String url;
    @Value("${hotel.database.username}")
    private String username;
    @Value("${hotel.database.password:}")
    private String password;

    public void initialize() {
        try (Connection c = connect(); Statement s = c.createStatement()) {
            // 系统启动时自动建表，老师导入或首次运行时不需要手动创建表结构。
            s.executeUpdate("CREATE TABLE IF NOT EXISTS room_types (id BIGINT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(50) NOT NULL, bed_type VARCHAR(50) NOT NULL, capacity INT NOT NULL, price DECIMAL(12,2) NOT NULL, description VARCHAR(255))");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS rooms (id BIGINT PRIMARY KEY AUTO_INCREMENT, room_number VARCHAR(20) NOT NULL UNIQUE, floor VARCHAR(20) NOT NULL, type_id BIGINT NOT NULL, status VARCHAR(20) NOT NULL DEFAULT 'AVAILABLE', remark VARCHAR(255), CONSTRAINT fk_rooms_type FOREIGN KEY (type_id) REFERENCES room_types(id))");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS reservations (id BIGINT PRIMARY KEY AUTO_INCREMENT, guest_name VARCHAR(50) NOT NULL, phone VARCHAR(30) NOT NULL, id_card VARCHAR(30), room_type_id BIGINT NOT NULL, room_id BIGINT NOT NULL, check_in_date DATE NOT NULL, check_out_date DATE NOT NULL, guests INT NOT NULL DEFAULT 1, deposit DECIMAL(12,2) NOT NULL DEFAULT 0, total_amount DECIMAL(12,2) NOT NULL DEFAULT 0, status VARCHAR(20) NOT NULL DEFAULT 'BOOKED', note VARCHAR(255), created_at DATETIME NOT NULL, checked_in_at DATETIME, checked_out_at DATETIME, CONSTRAINT fk_reservation_room_type FOREIGN KEY (room_type_id) REFERENCES room_types(id), CONSTRAINT fk_reservation_room FOREIGN KEY (room_id) REFERENCES rooms(id))");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS users (id BIGINT PRIMARY KEY AUTO_INCREMENT, username VARCHAR(40) NOT NULL UNIQUE, password_hash VARCHAR(80) NOT NULL, role VARCHAR(20) NOT NULL, display_name VARCHAR(50) NOT NULL, enabled TINYINT(1) NOT NULL DEFAULT 1)");
            seedDefaultUsers();
            seedIfEmpty();
        } catch (SQLException e) {
            throw new IllegalStateException("数据库初始化失败：" + e.getMessage(), e);
        }
    }

    public List<RoomType> findRoomTypes() {
        // 查询全部房型，基础维护和房态图都会使用。
        List<RoomType> list = new ArrayList<>();
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement("SELECT * FROM room_types ORDER BY id"); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(mapRoomType(rs));
            return list;
        } catch (SQLException e) {
            throw new IllegalStateException(e.getMessage(), e);
        }
    }

    public RoomType insertRoomType(RoomType t) {
        // 插入房型后读取数据库自增 ID，返回给业务层继续使用。
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement("INSERT INTO room_types(name, bed_type, capacity, price, description) VALUES(?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
            fillRoomType(ps, t);
            ps.executeUpdate();
            t.setId(generatedId(ps));
            return t;
        } catch (SQLException e) {
            throw new IllegalStateException(e.getMessage(), e);
        }
    }

    public void updateRoomType(RoomType t) {
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement("UPDATE room_types SET name=?, bed_type=?, capacity=?, price=?, description=? WHERE id=?")) {
            fillRoomType(ps, t);
            ps.setLong(6, t.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException(e.getMessage(), e);
        }
    }

    public void deleteRoomType(Long id) {
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement("DELETE FROM room_types WHERE id=?")) {
            ps.setLong(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException(e.getMessage(), e);
        }
    }

    public List<Room> findRooms() {
        // 按房号排序查询客房，保证房态图显示顺序稳定。
        List<Room> list = new ArrayList<>();
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement("SELECT * FROM rooms ORDER BY room_number"); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(mapRoom(rs));
            return list;
        } catch (SQLException e) {
            throw new IllegalStateException(e.getMessage(), e);
        }
    }

    public Room insertRoom(Room r) {
        // 新增客房，房号唯一约束由数据库和业务层共同保证。
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement("INSERT INTO rooms(room_number, floor, type_id, status, remark) VALUES(?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
            fillRoom(ps, r);
            ps.executeUpdate();
            r.setId(generatedId(ps));
            return r;
        } catch (SQLException e) {
            throw new IllegalStateException(e.getMessage(), e);
        }
    }

    public void updateRoom(Room r) {
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement("UPDATE rooms SET room_number=?, floor=?, type_id=?, status=?, remark=? WHERE id=?")) {
            fillRoom(ps, r);
            ps.setLong(6, r.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException(e.getMessage(), e);
        }
    }

    public void deleteRoom(Long id) {
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement("DELETE FROM rooms WHERE id=?")) {
            ps.setLong(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException(e.getMessage(), e);
        }
    }

    public List<Reservation> findReservations() {
        // 预订记录按创建时间倒序返回，让最新订单显示在最上方。
        List<Reservation> list = new ArrayList<>();
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement("SELECT * FROM reservations ORDER BY created_at DESC"); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(mapReservation(rs));
            return list;
        } catch (SQLException e) {
            throw new IllegalStateException(e.getMessage(), e);
        }
    }

    public Reservation insertReservation(Reservation r) {
        // 保存预订完整字段，包括金额、状态、创建时间和入住/退房时间。
        String sql = "INSERT INTO reservations(guest_name,phone,id_card,room_type_id,room_id,check_in_date,check_out_date,guests,deposit,total_amount,status,note,created_at,checked_in_at,checked_out_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            fillReservation(ps, r);
            ps.executeUpdate();
            r.setId(generatedId(ps));
            return r;
        } catch (SQLException e) {
            throw new IllegalStateException(e.getMessage(), e);
        }
    }

    public void updateReservation(Reservation r) {
        String sql = "UPDATE reservations SET guest_name=?,phone=?,id_card=?,room_type_id=?,room_id=?,check_in_date=?,check_out_date=?,guests=?,deposit=?,total_amount=?,status=?,note=?,created_at=?,checked_in_at=?,checked_out_at=? WHERE id=?";
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            fillReservation(ps, r);
            ps.setLong(16, r.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException(e.getMessage(), e);
        }
    }

    public void clearReservations() {
        // 清空预订记录后释放已预订/入住中的房间，避免房态卡住。
        try (Connection c = connect(); Statement s = c.createStatement()) {
            s.executeUpdate("DELETE FROM reservations");
            s.executeUpdate("UPDATE rooms SET status='AVAILABLE', remark='' WHERE status IN ('RESERVED','OCCUPIED')");
        } catch (SQLException e) {
            throw new IllegalStateException(e.getMessage(), e);
        }
    }

    public UserAccount findUserByUsername(String username) {
        // 登录时按账号查询用户，密码校验在 AuthService 中完成。
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement("SELECT * FROM users WHERE username=?")) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                return mapUser(rs);
            }
        } catch (SQLException e) {
            throw new IllegalStateException(e.getMessage(), e);
        }
    }

    public List<String> tableNames() {
        return TABLE_NAMES;
    }

    public DatabaseTableView tableView(String tableName) {
        // 数据库查看器返回列名和行数据，前端据此动态渲染表格。
        if (!TABLE_NAMES.contains(tableName)) throw new IllegalArgumentException("不支持查看该数据表");
        List<String> columns = new ArrayList<>();
        List<Map<String, Object>> rows = new ArrayList<>();
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement("SELECT * FROM " + tableName + " ORDER BY id DESC"); ResultSet rs = ps.executeQuery()) {
            int count = rs.getMetaData().getColumnCount();
            for (int i = 1; i <= count; i++) columns.add(rs.getMetaData().getColumnLabel(i));
            while (rs.next()) {
                Map<String, Object> row = new LinkedHashMap<>();
                for (String column : columns) row.put(column, rs.getObject(column));
                rows.add(row);
            }
            return new DatabaseTableView(tableName, columns, rows);
        } catch (SQLException e) {
            throw new IllegalStateException(e.getMessage(), e);
        }
    }

    private void seedIfEmpty() throws SQLException {
        // 首次运行时写入演示房型和客房，方便直接打开系统演示。
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM room_types"); ResultSet rs = ps.executeQuery()) {
            rs.next();
            if (rs.getLong(1) > 0) return;
        }
        RoomType a = insertRoomType(new RoomType(null, "标准双床房", "双床", 2, new BigDecimal("288"), "适合商务出行，含早餐"));
        RoomType b = insertRoomType(new RoomType(null, "豪华大床房", "大床", 2, new BigDecimal("398"), "高楼层景观房"));
        RoomType d = insertRoomType(new RoomType(null, "行政套房", "套房", 4, new BigDecimal("688"), "独立会客区，适合家庭入住"));
        insertRoom(new Room(null, "201", "2F", a.getId(), RoomStatus.AVAILABLE, ""));
        insertRoom(new Room(null, "202", "2F", a.getId(), RoomStatus.AVAILABLE, ""));
        insertRoom(new Room(null, "203", "2F", a.getId(), RoomStatus.MAINTENANCE, "空调检修"));
        insertRoom(new Room(null, "301", "3F", b.getId(), RoomStatus.AVAILABLE, ""));
        insertRoom(new Room(null, "302", "3F", b.getId(), RoomStatus.AVAILABLE, ""));
        insertRoom(new Room(null, "401", "4F", d.getId(), RoomStatus.AVAILABLE, ""));
    }

    private void seedDefaultUsers() throws SQLException {
        // 默认账号：管理员、经理、前台员工、保洁，便于验收时演示权限差异。
        insertUserIfMissing("admin", "admin123", UserRole.ADMIN, "系统管理员");
        insertUserIfMissing("manager", "manager123", UserRole.MANAGER, "客房经理");
        insertUserIfMissing("staff", "staff123", UserRole.STAFF, "前台员工");
        insertUserIfMissing("cleaner", "cleaner123", UserRole.HOUSEKEEPING, "保洁人员");
    }

    private void insertUserIfMissing(String username, String password, UserRole role, String displayName) throws SQLException {
        // 已存在账号不重复插入，避免每次重启都生成重复用户。
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM users WHERE username=?")) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                if (rs.getLong(1) > 0) return;
            }
        }
        insertUser(username, password, role, displayName);
    }

    private void insertUser(String username, String password, UserRole role, String displayName) throws SQLException {
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement("INSERT INTO users(username,password_hash,role,display_name,enabled) VALUES(?,?,?,?,1)")) {
            ps.setString(1, username);
            ps.setString(2, AuthService.hashPassword(password));
            ps.setString(3, role.name());
            ps.setString(4, displayName);
            ps.executeUpdate();
        }
    }

    private Connection connect() throws SQLException {
        // 统一从 application.yml 中读取 MySQL 连接参数。
        return DriverManager.getConnection(url, username, password);
    }

    private RoomType mapRoomType(ResultSet rs) throws SQLException {
        return new RoomType(rs.getLong("id"), rs.getString("name"), rs.getString("bed_type"), rs.getInt("capacity"), rs.getBigDecimal("price"), rs.getString("description"));
    }

    private Room mapRoom(ResultSet rs) throws SQLException {
        return new Room(rs.getLong("id"), rs.getString("room_number"), rs.getString("floor"), rs.getLong("type_id"), RoomStatus.valueOf(rs.getString("status")), rs.getString("remark"));
    }

    private Reservation mapReservation(ResultSet rs) throws SQLException {
        Reservation r = new Reservation();
        r.setId(rs.getLong("id"));
        r.setGuestName(rs.getString("guest_name"));
        r.setPhone(rs.getString("phone"));
        r.setIdCard(rs.getString("id_card"));
        r.setRoomTypeId(rs.getLong("room_type_id"));
        r.setRoomId(rs.getLong("room_id"));
        r.setCheckInDate(rs.getDate("check_in_date").toLocalDate());
        r.setCheckOutDate(rs.getDate("check_out_date").toLocalDate());
        r.setGuests(rs.getInt("guests"));
        r.setDeposit(rs.getBigDecimal("deposit"));
        r.setTotalAmount(rs.getBigDecimal("total_amount"));
        r.setStatus(ReservationStatus.valueOf(rs.getString("status")));
        r.setNote(rs.getString("note"));
        r.setCreatedAt(toLocal(rs.getTimestamp("created_at")));
        r.setCheckedInAt(toLocal(rs.getTimestamp("checked_in_at")));
        r.setCheckedOutAt(toLocal(rs.getTimestamp("checked_out_at")));
        return r;
    }

    private UserAccount mapUser(ResultSet rs) throws SQLException {
        return new UserAccount(rs.getLong("id"), rs.getString("username"), rs.getString("password_hash"), UserRole.valueOf(rs.getString("role")), rs.getString("display_name"), rs.getBoolean("enabled"));
    }

    private void fillRoomType(PreparedStatement ps, RoomType t) throws SQLException {
        ps.setString(1, t.getName());
        ps.setString(2, t.getBedType());
        ps.setInt(3, t.getCapacity());
        ps.setBigDecimal(4, t.getPrice());
        ps.setString(5, t.getDescription());
    }

    private void fillRoom(PreparedStatement ps, Room r) throws SQLException {
        ps.setString(1, r.getRoomNumber());
        ps.setString(2, r.getFloor());
        ps.setLong(3, r.getTypeId());
        ps.setString(4, r.getStatus().name());
        ps.setString(5, r.getRemark());
    }

    private void fillReservation(PreparedStatement ps, Reservation r) throws SQLException {
        ps.setString(1, r.getGuestName());
        ps.setString(2, r.getPhone());
        ps.setString(3, r.getIdCard());
        ps.setLong(4, r.getRoomTypeId());
        ps.setLong(5, r.getRoomId());
        ps.setDate(6, Date.valueOf(r.getCheckInDate()));
        ps.setDate(7, Date.valueOf(r.getCheckOutDate()));
        ps.setInt(8, r.getGuests());
        ps.setBigDecimal(9, r.getDeposit());
        ps.setBigDecimal(10, r.getTotalAmount());
        ps.setString(11, r.getStatus().name());
        ps.setString(12, r.getNote());
        ps.setTimestamp(13, Timestamp.valueOf(r.getCreatedAt()));
        ps.setTimestamp(14, toTimestamp(r.getCheckedInAt()));
        ps.setTimestamp(15, toTimestamp(r.getCheckedOutAt()));
    }

    private Long generatedId(PreparedStatement ps) throws SQLException {
        try (ResultSet keys = ps.getGeneratedKeys()) {
            if (keys.next()) return keys.getLong(1);
        }
        throw new SQLException("未获取到自增 ID");
    }

    private LocalDateTime toLocal(Timestamp timestamp) {
        return timestamp == null ? null : timestamp.toLocalDateTime();
    }

    private Timestamp toTimestamp(LocalDateTime time) {
        return time == null ? null : Timestamp.valueOf(time);
    }
}
