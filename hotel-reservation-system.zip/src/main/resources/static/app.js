const { createApp } = Vue;
const today = new Date();
const tomorrow = new Date(Date.now() + 24 * 60 * 60 * 1000);
const toDateInput = (date) => date.toISOString().slice(0, 10);
// 如果直接用 file:// 打开页面，则请求本地 8080；通过 Spring Boot 访问时使用同源地址。
const apiBase = window.location.protocol === 'file:' ? 'http://localhost:8080' : '';

createApp({
    data() {
        // 刷新页面后从 localStorage 恢复登录态，避免用户每次刷新都重新登录。
        const savedUser = JSON.parse(localStorage.getItem('hotelUser') || 'null');
        return {
            activeTab: 'map',
            // 菜单项带权限标记，visibleTabs 会根据当前角色自动过滤。
            tabs: [
                { key: 'map', name: '房态图', icon: '▦' },
                { key: 'reservation', name: '预订记录', icon: '＋', frontDeskOnly: true },
                { key: 'checkin', name: '入住登记', icon: '✓', frontDeskOnly: true },
                { key: 'checkout', name: '退房结算', icon: '¥', frontDeskOnly: true },
                { key: 'settings', name: '基础维护', icon: '⚙', managerOnly: true }
            ],
            currentUser: savedUser,
            loginForm: { username: 'admin', password: 'admin123' },
            roomStatuses: [
                { value: 'AVAILABLE', label: '空闲' },
                { value: 'RESERVED', label: '已预订' },
                { value: 'OCCUPIED', label: '入住中' },
                { value: 'CLEANING', label: '清扫中' },
                { value: 'MAINTENANCE', label: '维修中' }
            ],
            dashboard: {},
            rooms: [],
            roomTypes: [],
            reservations: [],
            databaseTables: [],
            activeDatabaseTable: '',
            databaseTableView: { tableName: '', columns: [], rows: [] },
            keyword: '',
            reservationStatus: '',
            confirmClearReservations: false,
            checkoutTarget: null,
            message: { text: '', type: 'success' },
            reservationForm: { guestName: '', phone: '', idCard: '', roomTypeId: '', roomId: '', checkInDate: toDateInput(today), checkOutDate: toDateInput(tomorrow), guests: 1, deposit: 100, note: '' },
            checkoutForm: { extraCharge: 0, discount: 0, paymentMethod: '微信' },
            typeForm: { id: null, name: '', bedType: '', capacity: 2, price: 288, description: '' },
            roomForm: { roomNumber: '', floor: '', typeId: '', status: 'AVAILABLE', remark: '' }
        };
    },
    computed: {
        // 管理员拥有所有权限；经理负责基础维护；保洁只维护房态。
        isAdmin() { return this.currentUser && this.currentUser.role === 'ADMIN'; },
        canManageBase() { return this.currentUser && (this.currentUser.role === 'ADMIN' || this.currentUser.role === 'MANAGER'); },
        canFrontDesk() { return this.currentUser && this.currentUser.role !== 'HOUSEKEEPING'; },
        visibleTabs() { return this.tabs.filter(item => (!item.adminOnly || this.isAdmin) && (!item.managerOnly || this.canManageBase) && (!item.frontDeskOnly || this.canFrontDesk)); },
        currentTitle() { const tab = this.visibleTabs.find(item => item.key === this.activeTab); return tab ? tab.name : '房态图'; },
        availableRoomsForType() { return this.rooms.filter(room => room.status === 'AVAILABLE' && (!this.reservationForm.roomTypeId || room.typeId === this.reservationForm.roomTypeId)); },
        bookedReservations() { return this.reservations.filter(item => item.status === 'BOOKED'); },
        checkedInReservations() { return this.reservations.filter(item => item.status === 'CHECKED_IN'); },
        roomTypeStats() {
            return this.roomTypes.map(type => {
                const typedRooms = this.rooms.filter(room => room.typeId === type.id);
                return { ...type, total: typedRooms.length, available: typedRooms.filter(room => room.status === 'AVAILABLE').length, occupied: typedRooms.filter(room => room.status === 'OCCUPIED').length };
            });
        }
    },
    mounted() { if (this.currentUser) this.loadAll(); },
    methods: {
        async request(url, options = {}) {
            // 统一封装 fetch：自动带 JSON 头和登录 token，并统一处理错误提示。
            const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
            if (this.currentUser && this.currentUser.token) headers['X-Auth-Token'] = this.currentUser.token;
            const response = await fetch(apiBase + url, { ...options, headers });
            if (!response.ok) {
                const body = await response.json().catch(() => ({}));
                if (body.message === '请先登录') this.logout(false);
                throw new Error(body.message || '操作失败');
            }
            return response.json().catch(() => null);
        },
        async login() {
            try {
                // 登录成功后保存 token，后续接口通过 X-Auth-Token 识别当前用户。
                const user = await this.request('/api/auth/login', { method: 'POST', body: JSON.stringify(this.loginForm) });
                this.currentUser = user;
                localStorage.setItem('hotelUser', JSON.stringify(user));
                this.activeTab = 'map';
                this.toast(`欢迎回来，${user.displayName}`);
                await this.loadAll();
            } catch (e) { this.toast(e.message, 'error'); }
        },
        async logout(callApi = true) {
            // 退出时清理本地登录态和页面数据，回到登录页。
            if (callApi && this.currentUser) await this.request('/api/auth/logout', { method: 'POST' }).catch(() => null);
            this.currentUser = null;
            localStorage.removeItem('hotelUser');
            this.activeTab = 'map';
            this.dashboard = {};
            this.rooms = [];
            this.roomTypes = [];
            this.reservations = [];
            this.databaseTables = [];
        },
        async loadAll() {
            // 保洁不加载预订列表，避免看到客户隐私信息。
            const jobs = [this.loadDashboard(), this.loadRoomTypes(), this.loadRooms()];
            if (this.canFrontDesk) jobs.push(this.loadReservations());
            else this.reservations = [];
            await Promise.all(jobs);
            if (this.activeTab === 'database') await this.loadDatabaseTables();
        },
        async loadDashboard() { this.dashboard = await this.request('/api/dashboard'); },
        async loadRoomTypes() { this.roomTypes = await this.request('/api/room-types'); },
        async loadRooms() { this.rooms = await this.request('/api/room-map'); },
        async loadReservations() {
            const params = new URLSearchParams();
            if (this.keyword) params.set('keyword', this.keyword);
            if (this.reservationStatus) params.set('status', this.reservationStatus);
            this.reservations = await this.request('/api/reservations?' + params.toString());
        },
        async selectTab(key) {
            // 前端菜单也做一次权限提示；真正权限仍以后端接口校验为准。
            if (key === 'database' && !this.isAdmin) return this.toast('当前账号没有管理员权限', 'error');
            if (key === 'settings' && !this.canManageBase) return this.toast('当前账号没有经理权限', 'error');
            if ((key === 'reservation' || key === 'checkin' || key === 'checkout') && !this.canFrontDesk) return this.toast('当前账号没有前台业务权限', 'error');
            this.activeTab = key;
            if (key === 'database') await this.loadDatabaseTables();
        },
        async loadDatabaseTables() {
            // 数据库查看器先加载表名，再加载当前选中的表数据。
            this.databaseTables = await this.request('/api/database/tables');
            if (!this.activeDatabaseTable && this.databaseTables.length > 0) this.activeDatabaseTable = this.databaseTables[0];
            if (this.activeDatabaseTable) await this.loadDatabaseTable(this.activeDatabaseTable);
        },
        async loadDatabaseTable(tableName) { this.activeDatabaseTable = tableName; this.databaseTableView = await this.request(`/api/database/tables/${tableName}`); },
        async createReservation() {
            // 保存预订前先做页面必填校验，再提交给后端做最终业务校验。
            const validation = this.validateReservation();
            if (validation) return this.toast(validation, 'error');
            try {
                const payload = { ...this.reservationForm };
                if (payload.roomId === '') payload.roomId = null;
                await this.request('/api/reservations', { method: 'POST', body: JSON.stringify(payload) });
                this.toast('预订已保存');
                this.resetReservationForm();
                await this.loadAll();
            } catch (e) { this.toast(e.message, 'error'); }
        },
        validateReservation() {
            // 基础表单校验：减少无效请求，也让用户能马上看到错误原因。
            if (!this.reservationForm.guestName) return '请填写客人姓名';
            if (!this.reservationForm.phone) return '请填写联系电话';
            if (!this.reservationForm.roomTypeId) return '请选择房型';
            if (!this.reservationForm.checkInDate) return '请选择入住日期';
            if (!this.reservationForm.checkOutDate) return '请选择离店日期';
            if (this.reservationForm.checkOutDate <= this.reservationForm.checkInDate) return '离店日期必须晚于入住日期';
            if (this.availableRoomsForType.length === 0) return '该房型暂无可预订房间';
            return '';
        },
        async checkIn(item) {
            // 办理入住时可补录身份证号，后端会同步更新预订状态和房态。
            const idCard = item.idCard || window.prompt('请输入身份证号', '') || '';
            try { await this.request(`/api/reservations/${item.id}/check-in`, { method: 'POST', body: JSON.stringify({ idCard, extraDeposit: 0 }) }); this.toast('入住登记完成'); await this.loadAll(); } catch (e) { this.toast(e.message, 'error'); }
        },
        selectCheckout(item) { this.checkoutTarget = item; this.activeTab = 'checkout'; },
        async checkout() {
            if (!this.checkoutTarget) return;
            // 退房结算提交额外消费、优惠和支付方式，后端计算最终应收金额。
            try { await this.request(`/api/reservations/${this.checkoutTarget.id}/checkout`, { method: 'POST', body: JSON.stringify(this.checkoutForm) }); this.toast('退房结算完成'); this.checkoutTarget = null; this.checkoutForm = { extraCharge: 0, discount: 0, paymentMethod: '微信' }; await this.loadAll(); } catch (e) { this.toast(e.message, 'error'); }
        },
        async cancelReservation(item) {
            // 取消预订需要确认，避免误释放客房。
            if (!window.confirm(`确认取消 ${item.guestName} 的预订？`)) return;
            try { await this.request(`/api/reservations/${item.id}/cancel`, { method: 'POST' }); this.toast('预订已取消'); await this.loadAll(); } catch (e) { this.toast(e.message, 'error'); }
        },
        askClearReservations() {
            // 清空预订是危险操作，使用页面内二次确认。
            this.confirmClearReservations = true;
            this.toast('请再次点击“确认清空”执行删除');
        },
        async clearReservations() {
            try {
                await this.request('/api/reservations', { method: 'DELETE' });
                this.confirmClearReservations = false;
                this.toast('预订记录已清空');
                await this.loadAll();
            } catch (e) { this.toast(e.message, 'error'); }
        },
        async updateRoomStatus(id, status) {
            // 房态图下拉框直接调用后端更新房间状态。
            try { await this.request(`/api/rooms/${id}/status?status=${status}`, { method: 'PUT' }); this.toast(`房态已更新为${this.statusLabel(status)}`); await this.loadAll(); } catch (e) { this.toast(e.message, 'error'); }
        },
        prepareRoomForType(type) { this.roomForm.typeId = type.id; this.roomForm.status = 'AVAILABLE'; this.activeTab = 'settings'; this.toast(`请为 ${type.name} 添加客房`); },
        async saveRoomType() {
            // 房型表单同时支持新增和编辑，通过 id 判断使用 POST 还是 PUT。
            try { const method = this.typeForm.id ? 'PUT' : 'POST'; const url = this.typeForm.id ? `/api/room-types/${this.typeForm.id}` : '/api/room-types'; await this.request(url, { method, body: JSON.stringify(this.typeForm) }); this.toast('房型已保存'); this.resetTypeForm(); await this.loadAll(); } catch (e) { this.toast(e.message, 'error'); }
        },
        editRoomType(type) { this.typeForm = { ...type }; },
        async deleteRoomType(type) {
            if (!window.confirm(`确认删除房型 ${type.name}？`)) return;
            try { await this.request(`/api/room-types/${type.id}`, { method: 'DELETE' }); this.toast('房型已删除'); await this.loadAll(); } catch (e) { this.toast(e.message, 'error'); }
        },
        async saveRoom() {
            // 新增客房后刷新全部数据，房态图会立即同步出现新房间。
            try { await this.request('/api/rooms', { method: 'POST', body: JSON.stringify(this.roomForm) }); this.toast('客房已保存'); this.roomForm = { roomNumber: '', floor: '', typeId: '', status: 'AVAILABLE', remark: '' }; await this.loadAll(); } catch (e) { this.toast(e.message, 'error'); }
        },
        async deleteRoom(room) {
            // 删除客房仅管理员可见；后端还会检查是否有历史预订。
            if (!window.confirm(`确认删除 ${room.roomNumber} 房间？已有预订记录的房间不能删除。`)) return;
            try { await this.request(`/api/rooms/${room.id}`, { method: 'DELETE' }); this.toast('客房已删除'); await this.loadAll(); } catch (e) { this.toast(e.message, 'error'); }
        },
        resetTypeForm() { this.typeForm = { id: null, name: '', bedType: '', capacity: 2, price: 288, description: '' }; },
        resetReservationForm() { this.reservationForm = { guestName: '', phone: '', idCard: '', roomTypeId: '', roomId: '', checkInDate: toDateInput(today), checkOutDate: toDateInput(tomorrow), guests: 1, deposit: 100, note: '' }; },
        money(value) { return Number(value || 0).toFixed(2); },
        statusLabel(value) { const status = this.roomStatuses.find(item => item.value === value); return status ? status.label : value; },
        statusHint(value) { return ({ AVAILABLE: '可安排预订或入住', RESERVED: '已有预订待入住', OCCUPIED: '客人入住中', CLEANING: '等待清扫完成', MAINTENANCE: '维修处理中' })[value] || '暂无备注'; },
        tableLabel(tableName) { return ({ room_types: '房型表', rooms: '客房表', reservations: '预订表' })[tableName] || tableName; },
        formatCell(value) { return value === null || value === undefined || value === '' ? '-' : value; },
        toast(text, type = 'success') { this.message = { text, type }; window.setTimeout(() => { this.message.text = ''; }, 2600); }
    }
}).mount('#app');
