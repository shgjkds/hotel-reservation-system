-- 酒店客房预订管理系统 MySQL 建库建表脚本
-- 数据库：hotel_reservation

CREATE DATABASE IF NOT EXISTS hotel_reservation
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE hotel_reservation;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS reservations;
DROP TABLE IF EXISTS rooms;
DROP TABLE IF EXISTS room_types;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(40) NOT NULL UNIQUE,
  password_hash VARCHAR(80) NOT NULL,
  role VARCHAR(20) NOT NULL,
  display_name VARCHAR(50) NOT NULL,
  enabled TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE room_types (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(50) NOT NULL,
  bed_type VARCHAR(50) NOT NULL,
  capacity INT NOT NULL,
  price DECIMAL(12,2) NOT NULL,
  description VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO users (username, password_hash, role, display_name, enabled) VALUES
  ('admin', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'ADMIN', '系统管理员', 1),
  ('manager', '866485796cfa8d7c0cf7111640205b83076433547577511d81f8030ae99ecea5', 'MANAGER', '客房经理', 1),
  ('staff', '10176e7b7b24d317acfcf8d2064cfd2f24e154f7b5a96603077d5ef813d6a6b6', 'STAFF', '前台员工', 1),
  ('cleaner', 'c9311ad46bbd488bd393f8a9daffac1ba0bafef7bc5a5d847f197c41fb32692d', 'HOUSEKEEPING', '保洁人员', 1);

CREATE TABLE rooms (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  room_number VARCHAR(20) NOT NULL UNIQUE,
  floor VARCHAR(20) NOT NULL,
  type_id BIGINT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'AVAILABLE',
  remark VARCHAR(255),
  CONSTRAINT fk_rooms_type FOREIGN KEY (type_id) REFERENCES room_types(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE reservations (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  guest_name VARCHAR(50) NOT NULL,
  phone VARCHAR(30) NOT NULL,
  id_card VARCHAR(30),
  room_type_id BIGINT NOT NULL,
  room_id BIGINT NOT NULL,
  check_in_date DATE NOT NULL,
  check_out_date DATE NOT NULL,
  guests INT NOT NULL DEFAULT 1,
  deposit DECIMAL(12,2) NOT NULL DEFAULT 0,
  total_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  status VARCHAR(20) NOT NULL DEFAULT 'BOOKED',
  note VARCHAR(255),
  created_at DATETIME NOT NULL,
  checked_in_at DATETIME,
  checked_out_at DATETIME,
  CONSTRAINT fk_reservation_room_type FOREIGN KEY (room_type_id) REFERENCES room_types(id),
  CONSTRAINT fk_reservation_room FOREIGN KEY (room_id) REFERENCES rooms(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO room_types (id, name, bed_type, capacity, price, description) VALUES
  (1, '标准双床房', '双床', 2, 288.00, '适合商务出行，含早餐'),
  (2, '豪华大床房', '大床', 2, 398.00, '高楼层景观房'),
  (3, '行政套房', '套房', 4, 688.00, '独立会客区，适合家庭入住');

INSERT INTO rooms (room_number, floor, type_id, status, remark) VALUES
  ('201', '2F', 1, 'AVAILABLE', ''),
  ('202', '2F', 1, 'AVAILABLE', ''),
  ('203', '2F', 1, 'MAINTENANCE', '空调检修'),
  ('301', '3F', 2, 'AVAILABLE', ''),
  ('302', '3F', 2, 'AVAILABLE', ''),
  ('401', '4F', 3, 'AVAILABLE', '');
